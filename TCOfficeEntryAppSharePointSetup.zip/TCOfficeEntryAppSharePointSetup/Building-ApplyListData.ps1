#Config Variables
$SiteURL = "https://TARGET_TENANT.sharepoint.com/sites/TARGET_SITE/"
$ListName = "Building"
$CSVFolder = "C:\Temp\TCOfficeEntryApp\"
$CSVFields=@("Title","BuildingEnglishText","BuildingFrenchText","BuildingShortText","RegionEnglishText","RegionFrenchText","RegionSortOrder","Address","City","TimeZone","TimeZoneOffset") # Not currently being used below
###!!! CSV Fields need to be hard coded in script below. 
###To Do: investigate using for loop to iterate through columns 
 
#Get the CSV file contents
$CSVData = Import-Csv -Path ($CSVFolder + $ListName + ".csv") -header "Title","BuildingEnglishText","BuildingFrenchText","BuildingShortText","RegionEnglishText","RegionFrenchText","RegionSortOrder","Address","City","TimeZone","TimeZoneOffset" -delimiter "|" -Encoding Unicode
 
#Connect to site
Connect-PnPOnline $SiteUrl -UseWebLogin
 
#Iterate through each Row in the CSV and import data to SharePoint Online List
foreach ($Row in $CSVData)
{
	if ($Row.Title -ne "Title")	
	{

		Add-PnPListItem -List $ListName -Values @{"Title" = $($Row.Title)
                            "BuildingEnglishText" = $($Row.BuildingEnglishText)
                            "BuildingFrenchText" = $($Row.BuildingFrenchText)
                            }
    }
}

