#Config Variables
$SiteURL = "https://TARGET_TENANT.sharepoint.com/sites/TARGET_SITE/"
$TemplateFile = "C:\Temp\TCOfficeEntryApp\OfficeEntryListSchemas.xml"
 
#Connect to PNP Online
Connect-PnPOnline -Url $SiteURL -UseWebLogin
 
Write-Host "Creating List(s) from Template File..."
Apply-PnPProvisioningTemplate -Path $TemplateFile

